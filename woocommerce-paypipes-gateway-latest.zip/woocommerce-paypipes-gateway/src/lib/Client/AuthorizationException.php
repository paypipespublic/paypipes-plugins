<?php

namespace Paypipes\Client;

class AuthorizationException extends \Exception
{
    public static function from($message): self
    {
        return new self($message);
    }

}