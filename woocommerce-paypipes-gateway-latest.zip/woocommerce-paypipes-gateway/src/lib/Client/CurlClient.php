<?php

namespace Paypipes\Client;

class CurlClient implements ClientInterface
{

    /**
     * @param string $url
     * @param array $args
     * @return array
     * @throws \Paypipes\Client\ClientException
     */
    public function post(string $url, array $args): array
    {
	    if (!empty($args['body']) && is_array($args['body'])) {
		    $args['body'] = json_encode($args['body']);
	    }

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $args['body']);
        curl_setopt($curl, CURLOPT_POST, TRUE);

		$headers = ['Content-Type:application/json'];
		foreach ($args['header'] ?? [] as $key => $val) {
			$headers[] = $key .': '. $val;
		}

		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true );

        $response = curl_exec($curl);
        curl_close($curl);

        if ($error = curl_error($curl)) {
            throw ClientException::from( $error );
        }

        return json_decode($response, true);
    }
}