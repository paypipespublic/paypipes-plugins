<?php

use Paypipes\Client\WPClient;
use Paypipes\Gateway as Paypipes;
use Paypipes\Client\AuthorizationException;
use Paypipes\Client\ClientException;
use Paypipes\Request\Customer as CustomerRequest;
use Paypipes\Request\Purchase as PurchaseRequest;
use Paypipes\Response\InvalidResponseException;

/**
 * Paypipes Payments Gateway.
 *
 * @class       WC_Paypipes_Gateway
 * @extends     WC_Payment_Gateway
 * @package     WooCommerce/Classes/Payment
 */
class WC_Paypipes_Gateway extends WC_Payment_Gateway {

	const METHOD_CARD = 'card';
	const METHOD_WIRE = 'wire';
	const METHOD_CRYPTO = 'crypto';
	const CRYPTO_GATEWAY_CONFIRMO = 'confirmo';
	const CURRENCY_JPY = 'JPY';

    const PAYMENT_LOGOS = [
        'card' => [
            'googlepay.png',
            'applepay.svg',
            'creditcard.png',
        ],
        'wire' => [
            'wire.svg'
        ],
        'crypto' => [
            'bitcoin.svg',
            'ltc.svg',
            'eth.svg',
        ],
    ];

    private Paypipes $paypipes;
	private string $client_id;
	private string $client_secret;
	private string $base_url;
	private array $methods;
	private string $currency;
	private string $locale;
	private string $show_logo;

    private array $cardCurrencies;
    private array $wireCurrencies;

    private function log(string $msg, string $type = 'error')
    {
        wc_get_logger()->log($type, $msg, ['source' => 'Paypipes']);
    }

	public function __construct() {

		// load Paypipes SDK
		require_once PLUGIN_PATH . '/src/lib/autoload.php';

		// Setup general properties.
		$this->setup_properties();

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Hook payment actions
		$this->register_payment_actions();

        // Setup Paypipes API connection
		$this->paypipes = new Paypipes(
			$this->client_id,
			$this->client_secret,
			$this->base_url,
            new WPClient(),
		);

	}

	/**
	 * @return void
	 */
	public function setup_properties() {

		$this->id = 'paypipes_gateway';

		$this->title              = $this->get_option( 'title' );
		$this->has_fields         = true;
		$this->method_title       = _x( 'Woocommerce Paypipes Gateway', 'woocommerce-paypipes-gateway' );
		$this->method_description = __( 'Instant card and bank transfer payments. ', 'woocommerce-paypipes-gateway' );
		$this->show_logo          = $this->get_option( 'show_logo' );
		$this->methods            = array_values(array_filter( [
            $this->get_option( 'method_' . self::METHOD_CARD ) === 'yes' ? self::METHOD_CARD : null,
            $this->get_option( 'method_' . self::METHOD_WIRE ) === 'yes' ? self::METHOD_WIRE : null,
            $this->get_option( 'method_' . self::METHOD_CRYPTO ) === 'yes' ? self::METHOD_CRYPTO : null,
        ] ));
		$this->icon               = apply_filters('woocommerce_' . $this->id. '_icon',
            $this->getShowLogo() ? plugins_url( '../assets/images/paypipes.png', __FILE__ ) : ''
        );
		$this->currency           = get_woocommerce_currency();
		$this->locale             = strtolower( substr( get_bloginfo( 'language' ), 0, 2 ) );
		$this->client_id          = $this->get_option( 'client_id' );
		$this->client_secret      = $this->get_option( 'client_secret' );
		$this->base_url           = $this->get_option( 'base_url' );
        $this->cardCurrencies     = $this->get_option( 'card_currencies', [] );
        $this->wireCurrencies     = $this->get_option( 'wire_currencies', [] );

	}

	public function init_form_fields() {
		$this->form_fields = [
			'enabled'                     => [
				'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Paypipes Gateway', 'woocommerce-paypipes-gateway' ),
				'default' => 'yes'
			],
			'title'                       => [
				'title'       => __( 'Title', 'woocommerce-paypipes-gateway' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout. Can be empty.', 'woocommerce-paypipes-gateway' ),
				'default'     => __( 'Paypipes', 'woocommerce-paypipes-gateway' ),
				'desc_tip'    => true,
			],
			'client_id'                   => [
				'title'   => __( 'Client ID', 'woocommerce-paypipes-gateway' ),
				'type'    => 'text',
				'default' => '',
			],
			'client_secret'               => [
				'title'   => __( 'Client Secret (Live)', 'woocommerce-paypipes-gateway' ),
				'type'    => 'text',
				'default' => '',
			],
			'method_' . self::METHOD_CARD => [
				'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'default' => 'yes',
				'label'   => __( 'Enable Debit/Credit Card Payments', 'woocommerce-paypipes-gateway' ),
			],
            'card_currencies' => [
                'title'   => __( 'Card Currency', 'woocommerce-paypipes-gateway' ),
                'type'    => 'multiselect',
                'description' => __( 'If no currency is selected, the option applies to all currencies.', 'woocommerce-paypipes-gateway' ),
                'options'     => $this->getCurrencies(),
                'class'       => 'chosen_select',
                'custom_attributes' => [
                    'data-placeholder' => __('Select supported currencies...', '')
                ],
                'desc_tip'    => true,
            ],
			'method_' . self::METHOD_WIRE => [
				'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'default' => 'yes',
				'label'   => __( 'Enable Bank Transfer Payments', 'woocommerce-paypipes-gateway' ),
			],
            'wire_currencies' => [
                'title'   => __( 'Bank Transfer Currency', 'woocommerce-paypipes-gateway' ),
                'type'    => 'multiselect',
                'description' => __( 'If no currency is selected, the option applies to all currencies.', 'woocommerce-paypipes-gateway' ),
                'options'     => $this->getCurrencies(),
                'class'       => 'chosen_select',
                'custom_attributes' => [
                    'data-placeholder' => __('Select supported currencies...', '')
                ],
                'desc_tip'    => true,
            ],
            'method_' . self::METHOD_CRYPTO => [
                'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
                'type'    => 'checkbox',
                'default' => 'yes',
                'label'   => __( 'Enable Crypto Payments', 'woocommerce-paypipes-gateway' ),
            ],
			'show_logo'                   => [
				'title'   => __( 'Show Logos', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'label'   => __( 'Show Logos in checkout confirmation options', 'woocommerce-paypipes-gateway' ),
				'default' => 'yes'
			],
            'base_url'                    => [
                'title'   => __( 'API URL', 'woocommerce-paypipes-gateway' ),
                'type'    => 'select',
                'options'     => [
                    'https://secure.staging.paypipes.net' => 'https://secure.staging.paypipes.net',
                    'https://secure.paypipes.com' => 'https://secure.paypipes.com'
                ],
                'class'       => 'chosen_select',
                'default' => 'https://secure.staging.paypipes.net',
            ],
		];
	}

    public function payment_fields() {
        $methods = $this->getMethods();
        if ( ! count( $methods ) ) {
            ?>
            <p>Please enable at least one payment method on Settings page.</p>
            <?php
            return;
        }
        $fieldType = (count($methods) > 1) ? 'radio' : 'hidden';
        ?>
        <link rel='stylesheet' id='paypipes-custom-css'
              href='<?php echo plugins_url( PLUGIN_DIR_NAME . '/assets/css/custom.css' ); ?>' media='all'/>

        <?php if ( count( $methods ) > 0 ): ?>
            <fieldset id="<?php echo esc_attr( $this->id ); ?>_form" class='wc-payment-form'>
                <?php foreach ( $this->getMethods() as $key => $method ): ?>
                    <div class="form-row payment-method paypipes-form-row">
                        <input type="<?php echo $fieldType; ?>" name="paypipes_gateway_method" value="<?php echo $method; ?>"
                               id="payment_method_paypipes_gateway_<?php echo $method; ?>"
                        />
                        <label class="payment-method-label" for="payment_method_paypipes_gateway_<?php echo $method; ?>">
                            <span class="paypipes-payment-title"><?php echo getPaypipesTranslation( 'method_' . $method, $this->getLocale() ); ?></span>
                            <?php if ( $this->getShowLogo() ) { ?>
                                <div class="paypipes-payment-icons-wrapper">
                                    <?php if ($method === self::METHOD_CRYPTO): ?>
                                        <span style="line-height: 34px; vertical-align: middle; float: right; padding-left: 0.4em; ">
                                        <?php echo getPaypipesTranslation( 'others', $this->getLocale() ); ?>
                                    </span>
                                    <?php endif; ?>
                                    <?php foreach ( $this->getPaymentLogs($method) as $logo ): ?>
                                        <img src="<?php echo plugins_url( PLUGIN_DIR_NAME . '/assets/images/payment_methods/' . $logo); ?>"
                                             alt="" style="margin-left: 0; height: 34px;"/>
                                    <?php endforeach; ?>
                                </div>
                            <?php } ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </fieldset>
        <?php else: ?>
            <input type="hidden" name="paypipes_gateway_method" value="<?php echo $this->getMethods()[0]; ?>"
                   id="payment_method_paypipes_gateway_<?php echo $this->getMethods()[0]; ?>"/>
        <?php endif; ?>
        <?php

    }

    public function get_icon() {
        $icon_html = '';

        if ( $this->icon ) {
            $icon_html = sprintf( '<img src="%s" alt="%s" class="paypipes-payment-icon" />', esc_url( $this->icon ), esc_attr( $this->method_title ) );
        }

        return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
    }

    // Hook into the WooCommerce Edit Order page to add the Payment Method selected
    function add_payment_method_to_order($order)
    {
        $paymentMethod = get_post_meta($order->get_id() , '_payment_method', true);

        if ($paymentMethod)
        {
            echo '<p><strong>Payment Method: </strong>' . $paymentMethod . '</p>';
        }
    }

	/**
	 * @return void
	 */
	public function register_payment_actions() {
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );

	/*	add_filter( 'woocommerce_payment_complete_order_status', array(
			$this,
			'change_payment_complete_order_status'
		), 10, 3 );*/

		add_action( 'woocommerce_api_wc_' . $this->id . '_' . self::METHOD_CARD, [ $this, 'callback_card' ] );
		add_action( 'woocommerce_api_wc_' . $this->id . '_' . self::METHOD_WIRE, [ $this, 'callback_wire' ] );
		add_action( 'woocommerce_api_wc_' . $this->id . '_' . self::METHOD_CRYPTO, [ $this, 'callback_crypto' ] );

        //        add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		//add_action('woocommerce_before_checkout_form', [$this, 'checkout_response_error']);
		//add_action('before_woocommerce_pay', [$this, 'checkout_response_error']);

        add_action('woocommerce_admin_order_data_after_billing_address', [ $this, 'add_payment_method_to_order' ], 10, 1);
	}



	/**
	 * Change payment complete order status to completed for paypipes orders.
	 *
	 * @param string $status Current order status.
	 * @param int $order_id Order ID.
	 * @param WC_Order|false $order Order object.
	 *
	 * @return string
	 * @since  3.1.0
	 */
	public function change_payment_complete_order_status( $status, $order_id = 0, $order = false ): string
    {
        $this->log( 'Change Payment Complete FILTER: status:' . $status . ' order_id: ' . $order_id );
		if ( $order && ('paypipes_gateway' === $order->get_payment_method()) ) {
			$status = 'completed';
		}

		return $status;
	}


	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

        if (!$order) {
            $this->log( 'Checkout Invalid Order ID: ' . $order_id);
            return false;
        }

        if ($order->get_status() != 'pending') {
            global $woocommerce;
            $woocommerce->cart->empty_cart();
            wc_add_notice( 'Please make a new purchase as this order was already processed with status: ' . $order->get_status() . '!', 'error' );
            return false;

        }
		if ( ! ( $paymentMethod = $this->getPaymentMethod() ) ) {
			$this->log( 'Checkout Payment Method selection failed' . ' order_id: ' . $order_id . ' ' . $order->get_order_key(), 'notice');
			wc_add_notice( 'Please select a payment method!', 'error' );

			return false;
		}

		$ipAddress = WC_Geolocation::get_ip_address();
		$gateway   = '';
		$type      = '';

        if ( $paymentMethod === self::METHOD_CARD ) {
            $type = self::METHOD_CARD;
        } elseif ( $paymentMethod === self::METHOD_WIRE ) {
            $type = self::METHOD_WIRE;
        } elseif ( $paymentMethod === self::METHOD_CRYPTO ) {
            $gateway = self::CRYPTO_GATEWAY_CONFIRMO;
            $type = self::METHOD_CRYPTO;
        }

        update_post_meta($order_id, '_payment_method', $type);

		try {
			$customer = $this->paypipes->customer( new CustomerRequest(
				$order->get_billing_email(),
				$order->get_billing_first_name(),
				$order->get_billing_last_name(),
				$order->get_billing_address_1(),
				strlen($order->get_billing_city()) < 2 ? $order->get_billing_state() : $order->get_billing_city(),
				$order->get_billing_state(),
				$order->get_billing_country(),
				trim($order->get_billing_phone()),
				$order->get_billing_postcode(),
				$order->get_billing_email(),
			) );

			$purchase = $this->paypipes->purchase( new PurchaseRequest(
				$customer->getToken(),
				$gateway,
				$type,
				strtoupper( $order->get_currency() ),
				number_format( $order->get_total(), 2, '.', '' ),
				$order->get_id(),
				'Woocommerce Paypipes Payment for order ' . $order->get_id(),
				$ipAddress,
				$this->get_return_url( $order ),
				get_site_url() . '?wc-api=wc_' . $this->id . '_' . $paymentMethod,
				$this->getLocale(),
				'web'
			) );
		} catch ( ClientException|AuthorizationException|InvalidResponseException $e ) {

            $this->log('Order ID: ' . $order_id . ' Error: ' . $e->getMessage());
            $order->update_status( 'failed' );
            wc_add_notice( 'Unable to process order #' . $order->get_id() . ' Error : ' . $e->getMessage(), 'error' );

            return false;
		}

		return [
			'result'   => 'success',
			'redirect' => $purchase->getRedirectUrl()
		];

	}

    public function callback(string $method): void
    {
        $this->log( 'Callback triggered for method: ' . $method, 'debug');

        //$this->log('Headers: ' . json_encode($_SERVER), 'debug');

        $signature = $_SERVER['HTTP_SIGNATURE'] ?? '';

        $json =file_get_contents('php://input');
        if (!($response = json_decode($json, true))) {
            $this->log( 'Callback Invalid JSON body: ' . $json);
            header( 'HTTP/1.1 404 Not Found' );
            die();
        }

        $this->log( 'Callback signature: ' . $signature, 'debug');
        $this->log( 'Callback response: ' . json_encode($response), 'debug');

	    try {

		    $callback = $this->paypipes->callback( $signature, $response );

            $wc_order_id = $callback->getOrderId();

            $this->log( 'Callback processed WC order ID: ' . $wc_order_id . ' Paypipes Order ID:' . $callback->getOrderId() . 'Paypipes Transaction ID: ' . $callback->getTransactionId(), 'debug');

            $order = wc_get_order( $wc_order_id );
            if (!$order) {
                $this->log( 'Callback invalid order ID: ' . $callback->getOrderId());
                header( 'HTTP/1.1 404 Not Found' );
                die();
            }

            if ($order->get_status() != 'pending') {
                $this->log( 'Order is not in expected PENDING status: ' . $order->get_status() . ' Callback status: ' . $callback->getStatus(), 'warning');
            }

            switch ($callback->getStatus()) {
                case 'Approved':
                    $order->payment_complete($callback->getTransactionId());
                    $order->add_order_note('Order Completed via Paypipes.');
                    wc_reduce_stock_levels($order->get_id());
                    break;
	            case 'Cancelled':
                    $order->add_order_note('Order Cancelled via Paypipes.');
                    $order->update_status('cancelled');
                    break;
	            case 'Declined':
                    $order->add_order_note('Order Declined via Paypipes.');
                    $order->update_status('failed');
                    break;
                default:
                    $this->log( 'Callback triggered with unprocessable status: ' . $callback->getStatus(), 'debug');
                    $order->add_order_note('Unknown callback status received: ' . $callback->getStatus());
                    break;
            }

            $callbackResponse = json_encode($callback->getResponse());
            $this->log( 'Order updated, Response: ' . $callbackResponse, 'debug');
            $order->add_order_note('Response: ' . $callbackResponse);

	    } catch ( \Paypipes\Response\InvalidSignatureException|\Exception $e ) {
            $this->log( $e->getMessage());
            header( 'HTTP/1.1 404 Not Found' );
            die();
        }

        header( 'HTTP/1.1 200 OK' );
    }
	public function callback_card() {
        $this->callback(self::METHOD_CARD);
	}

    public function callback_wire() {
        $this->callback(self::METHOD_WIRE);
    }

    public function callback_crypto() {
        $this->callback(self::METHOD_CRYPTO);
    }

    protected function getAvailableMethods(): array {
		return [
			self::METHOD_CARD,
			self::METHOD_WIRE,
			self::METHOD_CRYPTO
		];
	}

	protected function getPaymentMethod() {
		if ( isset( $_POST['paypipes_gateway_method'] )
		     && in_array( $_POST['paypipes_gateway_method'], $this->getAvailableMethods() )
		) {
			return $_POST['paypipes_gateway_method'];
		}

		return false;
	}

	private function getLocale(): string {
		return $this->locale;
	}

    private function getMethods(): array {
        $methods = $this->methods;
        $order_id = intval($_GET['order_id'] ?? get_query_var('order-pay') ?? 0);
        $order = wc_get_order($order_id);
        $currency = $order ? $order->get_currency() : $this->currency;

        if (!empty($this->cardCurrencies) && !in_array($currency, $this->cardCurrencies)) {
            $methods = array_filter($methods, function ($item) {
                return $item !== self::METHOD_CARD;
            });
        }

        if (!empty($this->wireCurrencies) && !in_array($currency, $this->wireCurrencies)) {
            $methods = array_filter($methods, function ($item) {
                return $item !== self::METHOD_WIRE;
            });
        }
        return $methods;
    }

	private function getShowLogo(): bool {
		return $this->show_logo == 'yes';
	}

    private function getPaymentLogs(string $method): array
    {
        return self::PAYMENT_LOGOS[$method];
    }

    private function getCurrencies(): array {
        return [
            'ALL' => 'ALL' . ' - ' . __( 'Albanian lek', 'woocommerce' ),
            'AFN' => 'AFN' . ' - ' . __( 'Afghan afghani', 'woocommerce' ),
            'ARS' => 'ARS' . ' - ' . __( 'Argentine peso', 'woocommerce' ),
            'AWG' => 'AWG' . ' - ' . __( 'Aruban florin', 'woocommerce' ),
            'AUD' => 'AUD' . ' - ' . __( 'Australian dollar', 'woocommerce' ),
            'AZN' => 'AZN' . ' - ' . __( 'Azerbaijani manat', 'woocommerce' ),
            'BSD' => 'BSD' . ' - ' . __( 'Bahamian dollar', 'woocommerce' ),
            'BBD' => 'BBD' . ' - ' . __( 'Barbadian dollar', 'woocommerce' ),
            'BYN' => 'BYN' . ' - ' . __( 'Belarusian ruble', 'woocommerce' ),
            'BZD' => 'BZD' . ' - ' . __( 'Belize dollar', 'woocommerce' ),
            'BMD' => 'BMD' . ' - ' . __( 'Bermudian dollar', 'woocommerce' ),
            'BOB' => 'BOB' . ' - ' . __( 'Bolivian boliviano', 'woocommerce' ),
            'BAM' => 'BAM' . ' - ' . __( 'Bosnia and Herzegovina convertible mark', 'woocommerce' ),
            'BWP' => 'BWP' . ' - ' . __( 'Botswana pula', 'woocommerce' ),
            'BGN' => 'BGN' . ' - ' . __( 'Bulgarian lev', 'woocommerce' ),
            'BRL' => 'BRL' . ' - ' . __( 'Brazilian real', 'woocommerce' ),
            'BND' => 'BND' . ' - ' . __( 'Brunei dollar', 'woocommerce' ),
            'KHR' => 'KHR' . ' - ' . __( 'Cambodian riel', 'woocommerce' ),
            'CAD' => 'CAD' . ' - ' . __( 'Canadian dollar', 'woocommerce' ),
            'KYD' => 'KYD' . ' - ' . __( 'Cayman Islands dollar', 'woocommerce' ),
            'CLP' => 'CLP' . ' - ' . __( 'Chilean peso', 'woocommerce' ),
            'CNY' => 'CNY' . ' - ' . __( 'Chinese yuan', 'woocommerce' ),
            'COP' => 'COP' . ' - ' . __( 'Colombian peso', 'woocommerce' ),
            'CRC' => 'CRC' . ' - ' . __( 'Costa Rican col&oacute;n', 'woocommerce' ),
            'HRK' => 'HRK' . ' - ' . __( 'Croatian kuna', 'woocommerce' ),
            'CUP' => 'CUP' . ' - ' . __( 'Cuban peso', 'woocommerce' ),
            'CZK' => 'CZK' . ' - ' . __( 'Czech koruna', 'woocommerce' ),
            'DKK' => 'DKK' . ' - ' . __( 'Danish krone', 'woocommerce' ),
            'DOP' => 'DOP' . ' - ' . __( 'Dominican peso', 'woocommerce' ),
            'XCD' => 'XCD' . ' - ' . __( 'East Caribbean dollar', 'woocommerce' ),
            'EGP' => 'EGP' . ' - ' . __( 'Egyptian pound', 'woocommerce' ),
            'SVC' => 'SVC' . ' - ' . __( 'Salvadoran Colón', 'woocommerce' ), // currently not supported by Woocommerce
            'EUR' => 'EUR' . ' - ' . __( 'Euro', 'woocommerce' ),
            'FKP' => 'FKP' . ' - ' . __( 'Falkland Islands pound', 'woocommerce' ),
            'FJD' => 'FJD' . ' - ' . __( 'Fijian dollar', 'woocommerce' ),
            'GHS' => 'GHS' . ' - ' . __( 'Ghana cedi', 'woocommerce' ),
            'GIP' => 'GIP' . ' - ' . __( 'Gibraltar pound', 'woocommerce' ),
            'GTQ' => 'GTQ' . ' - ' . __( 'Guatemalan quetzal', 'woocommerce' ),
            'GGP' => 'GGP' . ' - ' . __( 'Guernsey pound', 'woocommerce' ),
            'GYD' => 'GYD' . ' - ' . __( 'Guyanese dollar', 'woocommerce' ),
            'HNL' => 'HNL' . ' - ' . __( 'Honduran lempira', 'woocommerce' ),
            'HKD' => 'HKD' . ' - ' . __( 'Hong Kong dollar', 'woocommerce' ),
            'HUF' => 'HUF' . ' - ' . __( 'Hungarian forint', 'woocommerce' ),
            'ISK' => 'ISK' . ' - ' . __( 'Icelandic kr&oacute;na', 'woocommerce' ),
            'INR' => 'INR' . ' - ' . __( 'Indian rupee', 'woocommerce' ),
            'IDR' => 'IDR' . ' - ' . __( 'Indonesian rupiah', 'woocommerce' ),
            'IRR' => 'IRR' . ' - ' . __( 'Iranian rial', 'woocommerce' ),
            'IMP' => 'IMP' . ' - ' . __( 'Manx pound', 'woocommerce' ),
            'ILS' => 'ILS' . ' - ' . __( 'Israeli new shekel', 'woocommerce' ),
            'JMD' => 'JMD' . ' - ' . __( 'Jamaican dollar', 'woocommerce' ),
            'JPY' => 'JPY' . ' - ' . __( 'Japanese yen', 'woocommerce' ),
            'JEP' => 'JEP' . ' - ' . __( 'Jersey pound', 'woocommerce' ),
            'KZT' => 'KZT' . ' - ' . __( 'Kazakhstani tenge', 'woocommerce' ),
            'KPW' => 'KPW' . ' - ' . __( 'North Korean won', 'woocommerce' ),
            'KRW' => 'KRW' . ' - ' . __( 'South Korean won', 'woocommerce' ),
            'KGS' => 'KGS' . ' - ' . __( 'Kyrgyzstani som', 'woocommerce' ),
            'LAK' => 'LAK' . ' - ' . __( 'Lao kip', 'woocommerce' ),
            'LBP' => 'LBP' . ' - ' . __( 'Lebanese pound', 'woocommerce' ),
            'LRD' => 'LRD' . ' - ' . __( 'Liberian dollar', 'woocommerce' ),
            'MKD' => 'MKD' . ' - ' . __( 'Macedonian denar', 'woocommerce' ),
            'MYR' => 'MYR' . ' - ' . __( 'Malaysian ringgit', 'woocommerce' ),
            'MUR' => 'MUR' . ' - ' . __( 'Mauritian rupee', 'woocommerce' ),
            'MXN' => 'MXN' . ' - ' . __( 'Mexican peso', 'woocommerce' ),
            'MNT' => 'MNT' . ' - ' . __( 'Mongolian t&ouml;gr&ouml;g', 'woocommerce' ),
            'MZN' => 'MZN' . ' - ' . __( 'Mozambican metical', 'woocommerce' ),
            'NAD' => 'NAD' . ' - ' . __( 'Namibian dollar', 'woocommerce' ),
            'NPR' => 'NPR' . ' - ' . __( 'Nepalese rupee', 'woocommerce' ),
            'ANG' => 'ANG' . ' - ' . __( 'Netherlands Antillean guilder', 'woocommerce' ),
            'NZD' => 'NZD' . ' - ' . __( 'New Zealand dollar', 'woocommerce' ),
            'NIO' => 'NIO' . ' - ' . __( 'Nicaraguan c&oacute;rdoba', 'woocommerce' ),
            'NGN' => 'NGN' . ' - ' . __( 'Nigerian naira', 'woocommerce' ),
            'NOK' => 'NOK' . ' - ' . __( 'Norwegian krone', 'woocommerce' ),
            'OMR' => 'OMR' . ' - ' . __( 'Omani rial', 'woocommerce' ),
            'PKR' => 'PKR' . ' - ' . __( 'Pakistani rupee', 'woocommerce' ),
            'PAB' => 'PAB' . ' - ' . __( 'Panamanian balboa', 'woocommerce' ),
            'PYG' => 'PYG' . ' - ' . __( 'Paraguayan guaran&iacute;', 'woocommerce' ),
            'PEN' => 'PEN' . ' - ' . __( 'Sol', 'woocommerce' ),
            'PHP' => 'PHP' . ' - ' . __( 'Philippine peso', 'woocommerce' ),
            'PLN' => 'PLN' . ' - ' . __( 'Polish z&#x142;oty', 'woocommerce' ),
            'QAR' => 'QAR' . ' - ' . __( 'Qatari riyal', 'woocommerce' ),
            'RON' => 'RON' . ' - ' . __( 'Romanian leu', 'woocommerce' ),
            'RUB' => 'RUB' . ' - ' . __( 'Russian ruble', 'woocommerce' ),
            'SHP' => 'SHP' . ' - ' . __( 'Saint Helena pound', 'woocommerce' ),
            'SAR' => 'SAR' . ' - ' . __( 'Saudi riyal', 'woocommerce' ),
            'RSD' => 'RSD' . ' - ' . __( 'Serbian dinar', 'woocommerce' ),
            'SCR' => 'SCR' . ' - ' . __( 'Seychellois rupee', 'woocommerce' ),
            'SGD' => 'SGD' . ' - ' . __( 'Singapore dollar', 'woocommerce' ),
            'SBD' => 'SBD' . ' - ' . __( 'Solomon Islands dollar', 'woocommerce' ),
            'SOS' => 'SOS' . ' - ' . __( 'Somali shilling', 'woocommerce' ),
            'ZAR' => 'ZAR' . ' - ' . __( 'South African rand', 'woocommerce' ),
            'LKR' => 'LKR' . ' - ' . __( 'Sri Lankan rupee', 'woocommerce' ),
            'SEK' => 'SEK' . ' - ' . __( 'Swedish krona', 'woocommerce' ),
            'CHF' => 'CHF' . ' - ' . __( 'Swiss franc', 'woocommerce' ),
            'SRD' => 'SRD' . ' - ' . __( 'Surinamese dollar', 'woocommerce' ),
            'SYP' => 'SYP' . ' - ' . __( 'Syrian pound', 'woocommerce' ),
            'TWD' => 'TWD' . ' - ' . __( 'New Taiwan dollar', 'woocommerce' ),
            'THB' => 'THB' . ' - ' . __( 'Thai baht', 'woocommerce' ),
            'TTD' => 'TTD' . ' - ' . __( 'Trinidad and Tobago dollar', 'woocommerce' ),
            'TRY' => 'TRY' . ' - ' . __( 'Turkish lira', 'woocommerce' ),
            'TVD' => 'TVD' . ' - ' . __( 'Tuvaluan dollar', 'woocommerce' ), // currently not supported by Woocommerce
            'UAH' => 'UAH' . ' - ' . __( 'Ukrainian hryvnia', 'woocommerce' ),
            'GBP' => 'GBP' . ' - ' . __( 'Pound sterling', 'woocommerce' ),
            'USD' => 'USD' . ' - ' . __( 'United States (US) dollar', 'woocommerce' ),
            'UYU' => 'UYU' . ' - ' . __( 'Uruguayan peso', 'woocommerce' ),
            'UZS' => 'UZS' . ' - ' . __( 'Uzbekistani som', 'woocommerce' ),
            'VEF' => 'VEF' . ' - ' . __( 'Venezuelan bol&iacute;var (2008–2018)', 'woocommerce' ),
            'VND' => 'VND' . ' - ' . __( 'Vietnamese &#x111;&#x1ed3;ng', 'woocommerce' ),
            'YER' => 'YER' . ' - ' . __( 'Yemeni rial', 'woocommerce' ),
            'ZWD' => 'ZWD' . ' - ' . __( 'Zimbabwean Dollar', 'woocommerce' ), // currently not supported by Woocommerce
        ];
    }
}
