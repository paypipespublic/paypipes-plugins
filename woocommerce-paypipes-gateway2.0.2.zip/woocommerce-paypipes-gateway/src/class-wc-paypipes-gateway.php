<?php

use Paypipes\Client\WPClient;
use Paypipes\Gateway as Paypipes;
use Paypipes\Client\AuthorizationException;
use Paypipes\Client\ClientException;
use Paypipes\Request\Customer as CustomerRequest;
use Paypipes\Request\Purchase as PurchaseRequest;
use Paypipes\Response\InvalidResponseException;

/**
 * Paypipes Payments Gateway.
 *
 * @class       WC_Paypipes_Gateway
 * @extends     WC_Payment_Gateway
 * @package     WooCommerce/Classes/Payment
 */
class WC_Paypipes_Gateway extends WC_Payment_Gateway {

	const METHOD_CARD = 'card';
	const METHOD_WIRE = 'wire';
	const METHOD_CRYPTO = 'crypto';
	const WIRE_GATEWAY_MAXCONNECT = 'maxconnect';
	const WIRE_GATEWAY_WALLETORY = 'walletorybridge';
	const CRYPTO_GATEWAY_CONFIRMO = 'confirmo';
	const CURRENCY_JPY = 'JPY';

    const PAYMENT_LOGOS = [
        'card' => [
            'googlepay.png',
            'applepay.svg',
            'creditcard.png',
        ],
        'wire' => [
            'wire.svg'
        ],
        'crypto' => [
            'bitcoin.svg',
            'ltc.svg',
            'eth.svg',
        ],
    ];

    private Paypipes $paypipes;
	private string $client_id;
	private string $client_secret;
	private string $api_id;
	private string $base_url;
	private array $methods;
	private string $currency;
	private string $locale;
	private string $show_logo;
	private string $instructions;
	private string $selected_wire;

    private function log(string $msg, string $type = 'error')
    {
        wc_get_logger()->log($type, $msg, ['source' => 'Paypipes']);
    }

	public function __construct() {

		// load Paypipes SDK
		require_once PLUGIN_PATH . '/src/lib/autoload.php';

		// Setup general properties.
		$this->setup_properties();

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Hook payment actions
		$this->register_payment_actions();

        // Setup Paypipes API connection
		$this->paypipes = new Paypipes(
			$this->client_id,
			$this->client_secret,
			$this->api_id,
			$this->base_url,
            new WPClient(),
		);

	}

	/**
	 * @return void
	 */
	public function setup_properties() {

		$this->id = 'paypipes_gateway';

		$this->title              = $this->get_option( 'title' );
		$this->has_fields         = true;
		$this->method_title       = _x( 'Woocommerce Paypipes Gateway', 'woocommerce-paypipes-gateway' );
		$this->method_description = __( 'Instant card and bank transfer payments. ', 'woocommerce-paypipes-gateway' );
		$this->show_logo          = $this->get_option( 'show_logo' );
		$this->methods            = array_values(array_filter( [
            $this->get_option( 'method_' . self::METHOD_CARD ) === 'yes' ? self::METHOD_CARD : null,
            $this->get_option( 'method_' . self::METHOD_WIRE ) === 'yes' ? self::METHOD_WIRE : null,
            $this->get_option( 'method_' . self::METHOD_CRYPTO ) === 'yes' ? self::METHOD_CRYPTO : null,
        ] ));
		$this->icon               = apply_filters('woocommerce_' . $this->id. '_icon',
            $this->getShowLogo() ? plugins_url( '../assets/images/paypipes.svg', __FILE__ ) : ''
        );
		$this->instructions       = $this->get_option( 'instructions' );
		$this->currency           = get_woocommerce_currency();
		$this->locale             = strtolower( substr( get_bloginfo( 'language' ), 0, 2 ) );
		$this->client_id          = $this->get_option( 'client_id' );
		$this->client_secret      = $this->get_option( 'client_secret' );
		$this->api_id             = $this->get_option( 'api_id' );
		$this->base_url           = $this->get_option( 'base_url' );
		$this->selected_wire       = $this->get_option( 'wire_gateway' );

	}

	public function init_form_fields() {
		$this->form_fields = [
			'enabled'                     => [
				'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Paypipes Gateway', 'woocommerce-paypipes-gateway' ),
				'default' => 'yes'
			],
			'title'                       => [
				'title'       => __( 'Title', 'woocommerce-paypipes-gateway' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-paypipes-gateway' ),
				'default'     => __( 'Paypipes', 'woocommerce-paypipes-gateway' ),
				'desc_tip'    => true,
			],
			'instructions'                => [
				'title'       => __( 'Instructions', 'woocommerce-paypipes-gateway' ),
				'type'        => 'text',
				'description' => __( 'This controls the instructions shown during checkout.', 'woocommerce-paypipes-gateway' ),
				'default'     => __( 'Pay using credit/debit card.', 'woocommerce-paypipes-gateway' ),
				'desc_tip'    => true,
			],
			'client_id'                   => [
				'title'   => __( 'Client ID', 'woocommerce-paypipes-gateway' ),
				'type'    => 'text',
				'default' => '',
			],
			'client_secret'               => [
				'title'   => __( 'Client Secret (Live)', 'woocommerce-paypipes-gateway' ),
				'type'    => 'text',
				'default' => '',
			],
			'api_id'                      => [
				'title'   => __( 'API ID (Live)', 'woocommerce-paypipes-gateway' ),
				'type'    => 'text',
				'default' => '',
			],
			'method_' . self::METHOD_CARD => [
				'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'default' => 'yes',
				'label'   => __( 'Enable Debit/Credit Card Payments', 'woocommerce-paypipes-gateway' ),
			],
			'method_' . self::METHOD_WIRE => [
				'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'default' => 'yes',
				'label'   => __( 'Enable Bank Transfer Payments', 'woocommerce-paypipes-gateway' ),
			],
            'method_' . self::METHOD_CRYPTO => [
                'title'   => __( 'Enable/Disable', 'woocommerce-paypipes-gateway' ),
                'type'    => 'checkbox',
                'default' => 'yes',
                'label'   => __( 'Enable Crypto Payments', 'woocommerce-paypipes-gateway' ),
            ],
            'wire_gateway'                 => [
                'title'   => __( 'Wire Gateway', 'woocommerce-paypipes-gateway' ),
                'type'    => 'select',
                'default' => self::WIRE_GATEWAY_MAXCONNECT,
                'options' => [
                    self::WIRE_GATEWAY_MAXCONNECT => __( self::WIRE_GATEWAY_MAXCONNECT, 'woocommerce-paypipes-gateway' ),
                    self::WIRE_GATEWAY_WALLETORY => __( self::WIRE_GATEWAY_WALLETORY, 'woocommerce-paypipes-gateway' ),
                ],
            ],
			'show_logo'                   => [
				'title'   => __( 'Show Logos', 'woocommerce-paypipes-gateway' ),
				'type'    => 'checkbox',
				'label'   => __( 'Show Logos in checkout confirmation options', 'woocommerce-paypipes-gateway' ),
				'default' => 'yes'
			],
			'base_url'                    => [
				'title'   => __( 'API URL', 'woocommerce-paypipes-gateway' ),
				'type'    => 'text',
				'default' => 'https://secure.paypipes.com',
			],
		];
	}

    public function payment_fields() {
        $methods = $this->getMethods();
        if ( ! count( $methods ) ) {
            ?>
            <p>Please enable at least one payment method on Settings page.</p>
            <?php
            return;
        }
        ?>
        <link rel='stylesheet' id='paypipes-custom-css'
              href='<?php echo plugins_url( PLUGIN_DIR_NAME . '/assets/css/custom.css' ); ?>' media='all'/>

        <?php if ( count( $methods ) < 2 ): ?>
            <p><?php echo wp_kses_post( wpautop( wptexturize( $this->instructions ) ) ) ?></p>
        <?php endif; ?>

        <?php if ( count( $methods ) > 1 ): ?>
            <fieldset id="<?php echo esc_attr( $this->id ); ?>_form" class='wc-payment-form'>
                <?php foreach ( $this->getMethods() as $key => $method ): ?>
                    <div class="form-row payment-method paypipes-form-row">
                        <input type="radio" name="paypipes_gateway_method" value="<?php echo $method; ?>"
                               id="payment_method_paypipes_gateway_<?php echo $method; ?>"
                        />
                        <label class="payment-method-label" for="payment_method_paypipes_gateway_<?php echo $method; ?>">
                            <span class="paypipes-payment-title"><?php echo getPaypipesTranslation( 'method_' . $method, $this->getLocale() ); ?></span>
                            <?php if ( $this->getShowLogo() ) { ?>
                                <div class="paypipes-payment-icons-wrapper">
                                    <?php if ($method === self::METHOD_CRYPTO): ?>
                                        <span style="line-height: 34px; vertical-align: middle; float: right; padding-left: 0.4em; ">
                                        <?php echo getPaypipesTranslation( 'others', $this->getLocale() ); ?>
                                    </span>
                                    <?php endif; ?>
                                    <?php foreach ( $this->getPaymentLogs($method) as $logo ): ?>
                                        <img src="<?php echo plugins_url( PLUGIN_DIR_NAME . '/assets/images/payment_methods/' . $logo); ?>"
                                             alt="" style="margin-left: 0; height: 34px;"/>
                                    <?php endforeach; ?>
                                </div>
                            <?php } ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </fieldset>
        <?php else: ?>
            <input type="hidden" name="paypipes_gateway_method" value="<?php echo $this->getMethods()[0]; ?>"
                   id="payment_method_paypipes_gateway_<?php echo $this->getMethods()[0]; ?>"/>
        <?php endif; ?>
        <?php

    }

    public function get_icon() {
        $icon_html = '';

        if ( $this->icon ) {
            $icon_html = sprintf( '<img src="%s" alt="%s" class="paypipes-payment-icon" />', esc_url( $this->icon ), esc_attr( $this->method_title ) );
        }

        return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
    }

    // Hook into the WooCommerce Edit Order page to add the Payment Method selected
    function add_payment_method_to_order($order)
    {
        $paymentMethod = get_post_meta($order->get_id() , '_payment_method', true);

        if ($paymentMethod)
        {
            echo '<p><strong>Payment Method: </strong>' . $paymentMethod . '</p>';
        }
    }

	/**
	 * @return void
	 */
	public function register_payment_actions() {
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );

	/*	add_filter( 'woocommerce_payment_complete_order_status', array(
			$this,
			'change_payment_complete_order_status'
		), 10, 3 );*/

		add_action( 'woocommerce_api_wc_' . $this->id . '_' . self::METHOD_CARD, [ $this, 'callback_card' ] );
		add_action( 'woocommerce_api_wc_' . $this->id . '_' . self::METHOD_WIRE, [ $this, 'callback_wire' ] );
		add_action( 'woocommerce_api_wc_' . $this->id . '_' . self::METHOD_CRYPTO, [ $this, 'callback_crypto' ] );

        //        add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		//add_action('woocommerce_before_checkout_form', [$this, 'checkout_response_error']);
		//add_action('before_woocommerce_pay', [$this, 'checkout_response_error']);

        add_action('woocommerce_admin_order_data_after_billing_address', [ $this, 'add_payment_method_to_order' ], 10, 1);
	}



	/**
	 * Change payment complete order status to completed for paypipes orders.
	 *
	 * @param string $status Current order status.
	 * @param int $order_id Order ID.
	 * @param WC_Order|false $order Order object.
	 *
	 * @return string
	 * @since  3.1.0
	 */
	public function change_payment_complete_order_status( $status, $order_id = 0, $order = false ): string
    {
        $this->log( 'Change Payment Complete FILTER: status:' . $status . ' order_id: ' . $order_id );
		if ( $order && ('paypipes_gateway' === $order->get_payment_method()) ) {
			$status = 'completed';
		}

		return $status;
	}


	public function process_payment( $order_id ) {

		$order = wc_get_order( $order_id );

        if (!$order) {
            $this->log( 'Checkout Invalid Order ID: ' . $order_id);
            return false;
        }

        if ($order->get_status() != 'pending') {
            global $woocommerce;
            $woocommerce->cart->empty_cart();
            wc_add_notice( 'Please make a new purchase as this order was already processed with status: ' . $order->get_status() . '!', 'error' );
            return false;

        }
		if ( ! ( $paymentMethod = $this->getPaymentMethod() ) ) {
			$this->log( 'Checkout Payment Method selection failed' . ' order_id: ' . $order_id . ' ' . $order->get_order_key(), 'notice');
			wc_add_notice( 'Please select a payment method!', 'error' );

			return false;
		}

		$ipAddress = WC_Geolocation::get_ip_address();
		$gateway   = '';
		$type      = '';

        if ( $paymentMethod === self::METHOD_CARD ) {
            $type = self::METHOD_CARD;
        } elseif ( $paymentMethod === self::METHOD_WIRE ) {
			$gateway = $this->selected_wire;
            $type = self::METHOD_WIRE;
        } elseif ( $paymentMethod === self::METHOD_CRYPTO ) {
            $gateway = self::CRYPTO_GATEWAY_CONFIRMO;
            $type = self::METHOD_CRYPTO;
        }

        update_post_meta($order_id, '_payment_method', $type);

		try {
			$customer = $this->paypipes->customer( new CustomerRequest(
				$order->get_billing_email(),
				$order->get_billing_first_name(),
				$order->get_billing_last_name(),
				$order->get_billing_address_1(),
				strlen($order->get_billing_city()) < 2 ? $order->get_billing_state() : $order->get_billing_city(),
				$order->get_billing_state(),
				$order->get_billing_country(),
				substr( $order->get_billing_phone(), 0, 3 ),
				substr( $order->get_billing_phone(), 3 ),
				$order->get_billing_postcode(),
				$order->get_billing_email(),
			) );

			$purchase = $this->paypipes->purchase( new PurchaseRequest(
				$customer->getToken(),
				$gateway,
				$type,
				strtoupper( $order->get_currency() ),
				number_format( $order->get_total(), 2, '.', '' ),
				$order->get_id(),
				'Woocommerce Paypipes Payment for order ' . $order->get_id(),
				$ipAddress,
				$this->get_return_url( $order ),
				get_site_url() . '?wc-api=wc_' . $this->id . '_' . $paymentMethod,
				$this->getLocale(),
				'web'
			) );
		} catch ( ClientException|AuthorizationException|InvalidResponseException $e ) {

            $this->log('Order ID: ' . $order_id . ' Error: ' . $e->getMessage());
            $order->update_status( 'failed' );
            wc_add_notice( 'Something went wrong, please contact support! Order ID: ' . $order->get_id(), 'error' );

            return false;
		}

		return [
			'result'   => 'success',
			'redirect' => $purchase->getRedirectUrl()
		];

	}

    public function callback(string $method): void
    {
        $this->log( 'Callback triggered for method: ' . $method, 'debug');

        //$this->log('Headers: ' . json_encode($_SERVER), 'debug');

        $signature = $_SERVER['HTTP_SIGNATURE'] ?? '';

        $json =file_get_contents('php://input');
        if (!($response = json_decode($json, true))) {
            $this->log( 'Callback Invalid JSON body: ' . $json);
            header( 'HTTP/1.1 404 Not Found' );
            die();
        }

        $this->log( 'Callback signature: ' . $signature, 'debug');
        $this->log( 'Callback response: ' . json_encode($response), 'debug');

	    try {

		    $callback = $this->paypipes->callback( $signature, $response );

            $wc_order_id = $callback->getOrderId();

            $this->log( 'Callback processed WC order ID: ' . $wc_order_id . ' Paypipes Order ID:' . $callback->getOrderId() . 'Paypipes Transaction ID: ' . $callback->getTransactionId(), 'debug');

            $order = wc_get_order( $wc_order_id );
            if (!$order) {
                $this->log( 'Callback invalid order ID: ' . $callback->getOrderId());
                header( 'HTTP/1.1 404 Not Found' );
                die();
            }

            if ($order->get_status() != 'pending') {
                $this->log( 'Order is not in expected PENDING status: ' . $order->get_status() . ' Callback status: ' . $callback->getStatus(), 'warning');
            }

            switch ($callback->getStatus()) {
                case 'Approved':
                    $order->payment_complete($callback->getTransactionId());
                    $order->add_order_note('Order Completed via Paypipes.');
                    wc_reduce_stock_levels($order->get_id());
                    break;
	            case 'Cancelled':
                    $order->add_order_note('Order Cancelled via Paypipes.');
                    $order->update_status('cancelled');
                    break;
	            case 'Declined':
                    $order->add_order_note('Order Declined via Paypipes.');
                    $order->update_status('failed');
                    break;
                default:
                    $this->log( 'Callback triggered with unprocessable status: ' . $callback->getStatus(), 'debug');
                    $order->add_order_note('Unknown callback status received: ' . $callback->getStatus());
                    break;
            }

            $callbackResponse = json_encode($callback->getResponse());
            $this->log( 'Order updated, Response: ' . $callbackResponse, 'debug');
            $order->add_order_note('Response: ' . $callbackResponse);

	    } catch ( \Paypipes\Response\InvalidSignatureException|\Exception $e ) {
            $this->log( $e->getMessage());
            header( 'HTTP/1.1 404 Not Found' );
            die();
        }

        header( 'HTTP/1.1 200 OK' );
    }
	public function callback_card() {
        $this->callback(self::METHOD_CARD);
	}

    public function callback_wire() {
        $this->callback(self::METHOD_WIRE);
    }

    public function callback_crypto() {
        $this->callback(self::METHOD_CRYPTO);
    }

    protected function getAvailableMethods(): array {
		return [
			self::METHOD_CARD,
			self::METHOD_WIRE,
			self::METHOD_CRYPTO
		];
	}

	protected function getPaymentMethod() {
		if ( isset( $_POST['paypipes_gateway_method'] )
		     && in_array( $_POST['paypipes_gateway_method'], $this->getAvailableMethods() )
		) {
			return $_POST['paypipes_gateway_method'];
		}

		return false;
	}

	private function getLocale(): string {
		return $this->locale;
	}

	private function getMethods(): array {
        // Use maxconnect only if the setting of bank transfer is enabled and wire is maxconnect and the currency is JPY
        if (in_array(self::METHOD_WIRE, $this->methods) &&
            $this->selected_wire === self::WIRE_GATEWAY_MAXCONNECT &&
            strtoupper($this->currency) !== self::CURRENCY_JPY
        ) {
            return array_filter($this->methods, function ($item) {
               return $item !== self::METHOD_WIRE;
            });
        }
		return $this->methods;
	}

	private function getShowLogo(): bool {
		return $this->show_logo == 'yes';
	}

    private function getPaymentLogs(string $method): array
    {
        return self::PAYMENT_LOGOS[$method];
    }

}
