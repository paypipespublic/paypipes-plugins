<?php

namespace Paypipes\Client;

interface ClientInterface
{
    /**
     * @param string $url
     * @param array $args
     * @throws \Paypipes\Client\ClientException
     * @return array
     */
    public function post(string $url, array $args): array;

}