<?php

namespace Paypipes\Response;

class InvalidResponseException extends \Exception
{
    public static function from($message): self
    {
        return new self($message);
    }
}