<?php

namespace Paypipes\Response;

class Callback
{
	protected string $status;
	protected string $statusCode;
	protected string $statusDescription;
	protected string $orderId;
	protected string $transactionId;
	protected string $transactionType;
	protected string $amount;
	protected string $currency;
	protected string $created;
	protected string $cardToken;
	protected string $customerToken;
	protected string $description;
	protected string $gateway;
	protected string $maskNumber;
	protected string $referenceNumber;
	protected string $requestId;
	protected string $applePay;
	protected string $googlePay;
	protected array $cards;
    protected array $bank;
    protected array $fees;
    protected array $meta;

    protected array $response = [];

	/**
	 * @throws \Paypipes\Response\InvalidSignatureException
	 */
	public function __construct(string $clientSecret, string $signature, array $response)
	{
		$this->validateSignature($clientSecret, $signature, $response);

        if (!empty($response)) {
            $this->response = $response;
        }

        if (!empty($response['status'])) {
            $this->setStatus($response['status']);
        }
        if (!empty($response['status_code'])) {
            $this->setStatusCode($response['status_code']);
        }
        if (!empty($response['status_description'])) {
            $this->setStatusDescription($response['status_description']);
        }
        if (!empty($response['created'])) {
            $this->setCreated($response['created']);
        }
        if (!empty($response['order_id'])) {
            $this->setOrderId($response['order_id']);
        }
        if (!empty($response['transaction_id'])) {
            $this->setTransactionId($response['transaction_id']);
        }
        if (!empty($response['transaction_type'])) {
            $this->setTransactionType($response['transaction_type']);
        }
        if (!empty($response['amount'])) {
            $this->setAmount($response['amount']);
        }
        if (!empty($response['currency'])) {
            $this->setCurrency($response['currency']);
        }
        if (!empty($response['card_token'])) {
            $this->setCardToken($response['card_token']);
        }
        if (!empty($response['customer_token'])) {
            $this->setCustomerToken($response['customer_token']);
        }
        if (!empty($response['description'])) {
            $this->setDescription($response['description']);
        }
        if (!empty($response['gateway'])) {
            $this->setGateway($response['gateway']);
        }
        if (!empty($response['reference_number'])) {
            $this->setReferenceNumber($response['reference_number']);
        }
        if (!empty($response['request_id'])) {
            $this->setRequestId($response['request_id']);
        }
        if (!empty($response['applepay'])) {
            $this->setApplePay($response['applepay']);
        }
        if (!empty($response['googlepay'])) {
            $this->setGooglePay($response['googlepay']);
        }
        if (!empty($response['card'])) {
            $this->setCards($response['card']);
        }
        if (!empty($response['bank'])) {
            $this->setBank($response['bank']);
        }
        if (!empty($response['fees'])) {
            $this->setFees($response['fees']);
        }
        if (!empty($response['meta'])) {
            $this->setMeta($response['meta']);
        }
	}

	/**
	 * @throws \Paypipes\Response\InvalidSignatureException
	 */
	private function validateSignature(string $clientSecret, string $signature, array $response ): void
	{
		if (empty($signature)) {
			throw InvalidSignatureException::from('Missing Signature Header!' . ' Body: ' . json_encode($response));
		}
		$headerSig = $signature;
		$calculatedSig = hash_hmac('sha512', json_encode($response), $clientSecret);

		if ($calculatedSig !== $headerSig) {
			throw InvalidSignatureException::from('Signature Mismatch! Provided Signature: ' . $headerSig . ' Calculated Signature: ' . $calculatedSig);
		}
	}

    public function getResponse(): array
    {
        return $this->response;
    }

	public function getStatus(): string
	{
		return $this->status;
	}

	protected function setStatus(string $status): void
	{
		$this->status = $status;
	}

	public function getStatusDescription(): string
	{
		return $this->statusDescription;
	}

	protected function setStatusDescription(string $statusDescription): void
	{
		$this->statusDescription = $statusDescription;
	}

	public function getStatusCode(): string {
		return $this->statusCode;
	}

	protected function setStatusCode( string $statusCode ): void {
		$this->statusCode = $statusCode;
	}

	public function getOrderId(): string {
		return $this->orderId;
	}

	protected function setOrderId( string $orderId ): void {
		$this->orderId = $orderId;
	}

	public function getTransactionId(): string {
		return $this->transactionId;
	}

	protected function setTransactionId( string $transactionId ): void {
		$this->transactionId = $transactionId;
	}

	public function getTransactionType(): string {
		return $this->transactionType;
	}

	protected function setTransactionType( string $transactionType ): void {
		$this->transactionType = $transactionType;
	}

	public function getAmount(): string {
		return $this->amount;
	}

	protected function setAmount( string $amount ): void {
		$this->amount = $amount;
	}

	public function getCurrency(): string {
		return $this->currency;
	}

	protected function setCurrency( string $currency ): void {
		$this->currency = $currency;
	}

	public function getCreated(): string {
		return $this->created;
	}

	protected function setCreated( string $created ): void {
		$this->created = $created;
	}

	public function getCardToken(): string {
		return $this->cardToken;
	}

	protected function setCardToken( string $cardToken ): void {
		$this->cardToken = $cardToken;
	}

	public function getCustomerToken(): string {
		return $this->customerToken;
	}

	protected function setCustomerToken( string $customerToken ): void {
		$this->customerToken = $customerToken;
	}

	public function getDescription(): string {
		return $this->description;
	}

	protected function setDescription( string $description ): void {
		$this->description = $description;
	}

	public function getGateway(): string {
		return $this->gateway;
	}

	protected function setGateway( string $gateway ): void {
		$this->gateway = $gateway;
	}

	public function getMaskNumber(): string {
		return $this->maskNumber;
	}

	protected function setMaskNumber( string $maskNumber ): void {
		$this->maskNumber = $maskNumber;
	}

	public function getReferenceNumber(): string {
		return $this->referenceNumber;
	}

	protected function setReferenceNumber( string $referenceNumber ): void {
		$this->referenceNumber = $referenceNumber;
	}

	public function getRequestId(): string {
		return $this->requestId;
	}

	protected function setRequestId( string $requestId ): void {
		$this->requestId = $requestId;
	}

	public function getApplePay(): string {
		return $this->applePay;
	}

	protected function setApplePay( string $applePay ): void {
		$this->applePay = $applePay;
	}

    public function getGooglePay(): string {
        return $this->googlePay;
    }

    protected function setGooglePay( string $googlePay ): void {
        $this->googlePay = $googlePay;
    }

	public function getCards(): array {
		return $this->cards;
	}

	protected function setCards( array $cards ): void {
		$this->cards = $cards;
	}

    public function getBank(): array
    {
        return $this->bank;
    }

    public function setBank(array $bank): void
    {
        $this->bank = $bank;
    }

    public function getFees(): array
    {
        return $this->fees;
    }

    public function setFees(array $fees): void
    {
        $this->fees = $fees;
    }

    public function getMeta(): array
    {
        return $this->meta;
    }

    public function setMeta(array $meta): void
    {
        $this->meta = $meta;
    }
}