<?php

namespace Paypipes\Request;

class Customer
{
    protected string $referenceId;
    protected string $firstName;
    protected string $lastName;
    protected string $street;
    protected string $city;
    protected string $state;
    protected string $country;
    protected string $postCode;
    protected string $phoneCode;
    protected string $phone;
    protected string $email;


    public function __construct(
        string $referenceId,
        string $firstName,
        string $lastName,
        string $street,
        string $city,
        string $state,
        string $country,
        string $phoneCode,
        string $phone,
        string $postCode,
        string $email
    ) {
        $this->referenceId = $referenceId;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->street = $street;
        $this->city = $city;
        $this->state = $state;
        $this->country = $country;
        $this->phoneCode = $phoneCode;
        $this->phone = $phone;
        $this->postCode = $postCode;
        $this->email = $email;
    }
    public function toArray(): array
    {
        return [
            'reference_id' => $this->referenceId,
            'first_name' => $this->firstName,
            'last_name' => $this->lastName,
            'street' => $this->street,
            'city' => $this->city,
            'state' => $this->state,
            'country' => $this->country,
            'post_code' => $this->postCode,
            'phone_code' => $this->phoneCode,
            'phone' => $this->phone,
            'email' => $this->email,
        ];
    }
}