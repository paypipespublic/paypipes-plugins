<?php

function getPaypipesTranslation($text, $locale = 'en') {
    $translate = '';

    $data = [
        'method_wire' => [
            'en' => 'Bank transfer',
            'ja' => '銀行振込',
            'cs' => 'Bankovní převod'
        ],
        'method_card' => [
            'en' => 'Credit or debit card',
            'ja' => 'クレジットカードまたはデビットカード',
            'cs' => 'Kreditní nebo debetní karta',
        ],
        'method_crypto' => [
            'en' => 'Crypto',
            'ja' => '暗号通貨',
            'cs' => 'Kryptoměna'
        ],
        'others' => [
            'en' => 'and others',
            'ja' => 'その他',
            'cs' => 'a další'
        ],
        '100.100.303' => [
            'en' => 'Rejected - card expired',
            'sk' => 'Exspirovaná karta',
            'cs' => 'Exspirovaná karta'
        ],
        '100.100.600' => [
            'en' => 'Rejected - invalid CVV',
            'sk' => 'Nesprávny CVV kód',
            'cs' => 'Nesprávný CVV kód'
        ],
        '100.100.601' => [
            'en' => 'Rejected - invalid CVV',
            'sk' => 'Neplatné CVV',
            'cs' => 'Neplatné CVV'
        ],
        '100.100.700' => [
            'en' => 'Rejected - invalid card number',
            'sk' => 'Nesprávne číslo karty',
            'cs' => 'Nesprávné číslo karty'
        ],
        '100.380.401' => [
            'en' => 'Rejected - failed 3DS authentication',
            'sk' => 'Nesprávny 3DS kód',
            'cs' => 'Nesprávný 3DS kód'
        ],
        '100.380.501' => [
            'en' => 'Rejected - failed 3DS authentication',
            'sk' => 'Nesprávny 3DS kód',
            'cs' => 'Nesprávný 3DS kód'
        ],
        '800.100.151' => [
            'en' => 'Rejected - invalid card number',
            'sk' => 'Nesprávne číslo karty',
            'cs' => 'Nesprávné číslo karty'
        ],
        '800.100.153' => [
            'en' => 'Rejected - invalid CVV',
            'sk' => 'Nesprávny CVV kód',
            'cs' => 'Nesprávný CVV kód'
        ],
        '800.100.155' => [
            'en' => 'Rejected - insufficient funds',
            'sk' => 'Nedostatok peňazí',
            'cs' => 'Nedostatek peněz'
        ],
        '800.100.157' => [
            'en' => 'Rejected - invalid expiry date',
            'sk' => 'Exspirovaná karta',
            'cs' => 'Exspirovaná karta'
        ],
        '800.100.161' => [
            'en' => 'Rejected - too many invalid tries',
            'sk' => 'Priveľa neúspešných pokusov',
            'cs' => 'Příliš mnoho neúspěšných pokusů'
        ],
        '800.100.162' => [
            'en' => 'Rejected - card limit exceeded',
            'sk' => 'Prekročený limit',
            'cs' => 'Překročen limit'
        ],
        '800.100.163' => [
            'en' => 'Rejected - card limit exceeded',
            'sk' => 'Prekročený limit',
            'cs' => 'Překročen limit'
        ],
        '800.120.101' => [
            'en' => 'Rejected - card limit exceeded',
            'sk' => 'Prekročený limit',
            'cs' => 'Překročen limit'
        ],
        '800.120.200' => [
            'en' => 'Rejected - card limit exceeded',
            'sk' => 'Prekročený limit',
            'cs' => 'Překročen limit'
        ],
        '800.120.201' => [
            'en' => 'Rejected - card limit exceeded',
            'sk' => 'Prekročený limit',
            'cs' => 'Překročen limit'
        ]
    ];

    if(isset($data[$text]) && isset($data[$text][$locale])) {
        $translate = $data[$text][$locale];
    }

    return $translate;
}