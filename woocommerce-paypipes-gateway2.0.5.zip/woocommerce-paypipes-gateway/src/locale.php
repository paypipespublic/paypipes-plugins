<?php

function getPaypipesTranslation($text, $locale = 'en') {
    $translate = '';

    $data = [
        'method_wire' => [
            'en' => 'Bank transfer',
            'ja' => '銀行振込',
            'cs' => 'Bankovní převod'
        ],
        'method_card' => [
            'en' => 'Credit or debit card',
            'ja' => 'クレジットカードまたはデビットカード',
            'cs' => 'Kreditní nebo debetní karta',
        ],
        'method_crypto' => [
            'en' => 'Crypto',
            'ja' => '暗号通貨',
            'cs' => 'Kryptoměna'
        ],
        'others' => [
            'en' => 'and others',
            'ja' => 'その他',
            'cs' => 'a další'
        ],
    ];

    if(isset($data[$text]) && isset($data[$text][$locale])) {
        $translate = $data[$text][$locale];
    }

    return $translate;
}