<?php

namespace Paypipes\Client;

class ClientException extends \Exception
{
    public static function from(string $message): self
    {
        return new self($message);
    }
}