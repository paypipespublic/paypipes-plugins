<?php

namespace Paypipes;

use Paypipes\Client\AuthorizationException;
use Paypipes\Client\ClientInterface;
use Paypipes\Client\CurlClient;
use Paypipes\Request\Customer as CustomerRequest;
use Paypipes\Response\Customer as CustomerResponse;
use Paypipes\Request\Purchase as PurchaseRequest;
use Paypipes\Response\Purchase as PurchaseResponse;
use Paypipes\Response\Callback;

class Gateway {

	protected string $clientId;
	protected string $clientSecret;
	protected string $apiId;
	protected string $baseUrl = 'https://secure.paypipes.com';
	protected string $apiVersion = 'v2';
	const AUTHORIZE_URL = 'oauth/token';
	const PURCHASE_URL = 'purchase';
	const CUSTOMER_URL = 'tokenize/customers';

	protected ClientInterface $client;
	protected string $accessToken = '';

	public function __construct(
		string $clientId,
		string $clientSecret,
		string $apiId,
		string $baseUrl = 'https://secure.paypipes.com',
        ClientInterface $client = null
	) {
        $this->clientId     = $clientId;
        $this->clientSecret = $clientSecret;
        $this->apiId        = $apiId;
        $this->baseUrl      = $baseUrl;
        $this->client       = is_null($client) ? new CurlClient() : $client;
    }

	/**
	 * @return void
	 * @throws \Paypipes\Client\AuthorizationException
	 * @throws \Paypipes\Client\ClientException
	 */
	protected function authorize(): void {
		if ( $this->getAccessToken() ) {
			return;
		}
		$args = [
			'body' => [
				'grant_type'    => 'client_credentials',
				'client_id'     => $this->clientId,
				'client_secret' => $this->clientSecret,
			],
		];

		$response = $this->client->post( $this->getAuthorizeUrl(), $args );

		if ( ! empty( $response['token_type'] )
		     && $response['token_type'] === 'Bearer'
		     && ! empty( $response['access_token'] )
		) {
			$this->setAccessToken( $response['access_token'] );

			return;
		}
		throw AuthorizationException::from( 'Error ' . __METHOD__ . ' Response' . json_encode($response));
	}

	/**
	 * @param \Paypipes\Request\Purchase $purchaseRequest
	 *
	 * @return \Paypipes\Response\Purchase
	 * @throws \Paypipes\Client\AuthorizationException
	 * @throws \Paypipes\Client\ClientException
	 * @throws \Paypipes\Response\InvalidResponseException
	 */
	public function purchase( PurchaseRequest $purchaseRequest ): PurchaseResponse {
		$this->authorize();

		$body = $purchaseRequest->toArray();

		$args = [
			'body'    => $body,
			'headers' => [
				'Authorization' => 'Bearer ' . $this->getAccessToken(),
			],
		];

		$response = $this->client->post( $this->getPurchaseUrl(), $args );
		return new PurchaseResponse( $response );
	}

	/**
	 * @param \Paypipes\Request\Customer $customerRequest
	 *
	 * @return \Paypipes\Response\Customer
	 * @throws \Paypipes\Client\AuthorizationException
	 * @throws \Paypipes\Client\ClientException
	 * @throws \Paypipes\Response\InvalidResponseException
	 */
	public function customer( CustomerRequest $customerRequest ): CustomerResponse {
		$this->authorize();

		$body = $customerRequest->toArray();

		$args = [
			'body'    => $body,
			'headers' => [
				'Authorization' => 'Bearer ' . $this->getAccessToken(),
			],
		];

		$response = $this->client->post( $this->getCustomerUrl(), $args );

		return new CustomerResponse( $response );
	}

	/**
	 * @throws \Paypipes\Response\InvalidSignatureException
	 */
	public function callback(string $signature, array $response): Callback
	{
		return new Callback(
			$this->clientSecret,
			$signature,
			$response
		);
	}

	/**
	 * @return string
	 */
	private function getAuthorizeUrl(): string {
		return rtrim( $this->baseUrl, '\\/' ) . '/' . self::AUTHORIZE_URL;
	}

	/**
	 * @return string
	 */
	private function getPurchaseUrl(): string {
		return rtrim( $this->baseUrl, '\\/' ) . '/api/' . $this->apiVersion . '/' . self::PURCHASE_URL;
	}

	/**
	 * @return string
	 */
	private function getCustomerUrl(): string {
		return rtrim( $this->baseUrl, '\\/' ) . '/api/' . $this->apiVersion . '/' . self::CUSTOMER_URL;
	}

	/**
	 * @return string
	 */
	private function getAccessToken(): string {
		return $this->accessToken;
	}

	/**
	 * @param string $access_token
	 *
	 * @return void
	 */
	private function setAccessToken( string $access_token ): void {
		$this->accessToken = $access_token;
	}

}