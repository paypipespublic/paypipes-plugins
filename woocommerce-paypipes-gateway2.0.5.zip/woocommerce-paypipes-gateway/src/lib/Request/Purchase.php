<?php

namespace Paypipes\Request;

class Purchase {

    protected string $customerToken;
    protected string $gateway;
    protected string $type;
    protected string $currency;
    protected string $amount;
    protected string $orderId;
    protected string $description;
    protected string $ipAddress;
    protected string $returnUrl;
    protected string $callbackUrl;
    protected string $language;
    protected string $origin;


    public function __construct(
        string $customerToken,
        string $gateway,
        string $type,
        string $currency,
        string $amount,
        string $orderId,
        string $description,
        string $ipAddress,
        string $returnUrl,
        string $callbackUrl,
        string $language = 'en',
        string $origin = 'web'
    ) {
        $this->customerToken = $customerToken;
        $this->gateway = $gateway;
        $this->type = $type;
        $this->amount = $amount;
        $this->currency = $currency;
        $this->orderId = $orderId;
        $this->description = $description;
        $this->ipAddress = $ipAddress;
        $this->returnUrl = $returnUrl;
        $this->callbackUrl = $callbackUrl;
        $this->language = $language;
        $this->origin = $origin;
    }
    public function toArray(): array
    {
        return [
            'customer_token' => $this->customerToken,
            'gateway' => $this->gateway,
            'type' => $this->type,
            'currency' => $this->currency,
            'amount' => $this->amount,
            'order_id' => $this->orderId,
            'description' => $this->description,
            'ip_address' => $this->ipAddress,
            'return_url' => $this->returnUrl,
            'callback_url' => $this->callbackUrl,
            'language' => $this->language,
            'origin' => $this->origin,
        ];
    }

}
