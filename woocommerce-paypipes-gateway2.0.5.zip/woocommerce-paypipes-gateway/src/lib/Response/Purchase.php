<?php

namespace Paypipes\Response;

class Purchase {

    protected string $redirectUrl;

    /**
     * @throws \Paypipes\Response\InvalidResponseException
     */
    public function __construct(array $response)
    {
        if (!empty($response) && !empty($response['redirect_url'])) {
            $this->setRedirectUrl($response['redirect_url']);
            return;
        }

	    throw InvalidResponseException::from('Error ' . __CLASS__ . ' Response: ' . json_encode($response));
    }

    public function getRedirectUrl(): string
    {
        return $this->redirectUrl;
    }

    protected function setRedirectUrl(string $redirectUrl): void
    {
        $this->redirectUrl = $redirectUrl;
    }
}
