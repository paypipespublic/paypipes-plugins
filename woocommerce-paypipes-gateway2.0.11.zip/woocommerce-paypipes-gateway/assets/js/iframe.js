jQuery(document).ready(function ($) {
    let baseUrl = '';
    let transactionId = '';
    jQuery(document).ajaxComplete(function (event, xhr, settings) {
       try {
           $('.blockUI.blockOverlay').hide(); // Hide default loader

           const response = JSON.parse(xhr.responseText);
           const paymentModal = localStorage.getItem('paymentModal');
           const paymentModalData = paymentModal ? JSON.parse(paymentModal) : {};
           baseUrl = paymentModalData.baseUrl ? paymentModalData.baseUrl : response.base_url;
           transactionId = paymentModalData.transactionId ? paymentModalData.transactionId : response.transaction_id;

           function showPaymentModal(src, height, width) {
               $('#paypipes-iframe').attr('src', src);
               $('#paypipes-modal-content').css({ height: height, width: width });
               $('#paypipes-payment-modal').show();
               $('body').css('overflow', 'hidden');
           }

           if (paymentModalData.visible === 'yes') {
               showPaymentModal( baseUrl + '/v2/payment?transaction=' +  paymentModalData.transactionId, paymentModalData.height, paymentModalData.width);
           }

           if (response.type === 'paypipes-iframe') {
               const height = response.iframe_height + 'px';
               const width = response.iframe_width + 'px';

               localStorage.setItem('paymentModal', JSON.stringify({
                   visible: 'yes',
                   height: height,
                   width: width,
                   baseUrl: baseUrl,
                   transactionId: response.transaction_id,
               }));

               showPaymentModal(response.iframe_src, height, width);
           }
        } catch (error) {
            console.error('Error parsing AJAX response:', error);
        }
    });

    window.addEventListener('message', (event) => {
        localStorage.removeItem('paymentModal');

        if (event.data.type === 'redirect' && event.data.url) {
            window.location.href = event.data.url;
        }

        if (event.data.action === 'CLOSE_CONFIRMO_OVERLAY') {
            $('#paypipes-iframe').attr('src', baseUrl + '/v2/merchant?transaction=' + transactionId);
        }
    });
});