<?php

namespace Paypipes\Response;

class InvalidSignatureException extends \Exception
{
    public static function from($message): self
    {
        return new self($message);
    }
}