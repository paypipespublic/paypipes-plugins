<?php

namespace Paypipes\Response;

class Customer
{
    protected string $token;

    /**
     * @throws \Paypipes\Response\InvalidResponseException
     */
    public function __construct(array $response)
    {
        if (!empty($response) && !empty($response['customer_token'])) {
            $this->setToken($response['customer_token']);
            return;
        }

        throw InvalidResponseException::from('Error ' . __CLASS__ . ' Response: ' . json_encode($response));
    }

    public function getToken(): string
    {
        return $this->token;
    }

    protected function setToken(string $token): void
    {
        $this->token = $token;
    }
}