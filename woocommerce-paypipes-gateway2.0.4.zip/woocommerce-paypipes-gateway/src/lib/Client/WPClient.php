<?php

namespace Paypipes\Client;

class WPClient implements ClientInterface
{

    /**
     * @param string $url
     * @param array $args
     * @return array
     * @throws \Paypipes\Client\ClientException
     */
    public function post(string $url, array $args): array
    {
        // force content-type: application/json
        $args['headers']['Content-Type'] = 'application/json';
        if (!empty($args['body']) && is_array($args['body'])) {
            $args['body'] = json_encode($args['body']);
        }

        $response = wp_remote_post( $url, $args );

        if ( ! is_wp_error( $response ) ) {
            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            return $body;
        } else {
            $error_message = $response->get_error_message();
            throw ClientException::from( $error_message );
        }
    }
}