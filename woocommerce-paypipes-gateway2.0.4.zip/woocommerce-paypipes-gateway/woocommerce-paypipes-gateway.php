<?php
/**
 * Plugin Name: Woocommerce Paypipes Gateway
 * Plugin URI: https://www.paypipes.com/
 * Description: This plugin add the Paypipes payment gateway which allow you to charge the Credit Card and make Instant bank transfer. <a href="https://www.paypipes.com/">www.paypipes.com</a>
 * Author: Purple Next
 * Author URI: https://purple-next.com
 * Version: 1.0.0
 * License: GPL2
 * License URL: http://www.gnu.org/licenses/gpl-2.0.txt
 * text-domain: woocommerce-paypipes-gateway
 *
 * @package WooCommerce\Paypipes
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) return;

define('PLUGIN_DIR_NAME', 'woocommerce-paypipes-gateway');
define('PLUGIN_PATH',  plugin_dir_path( __FILE__ ));
//define('PLUGIN_PATH', ABSPATH . '/wp-content/plugins/' . PLUGIN_DIR_NAME);

add_action( 'plugins_loaded', 'init_paypipes', 11 );
add_filter( 'woocommerce_payment_gateways', 'register_paypipes' );
//add_filter( 'woocommerce_currencies', 'set_currencies' );
//add_filter( 'woocommerce_currency_symbol', 'set_currencies_symbol', 10, 2 );

//add_filter( 'woocommerce_order_button_html', 'custom_button_html' );

function init_paypipes() {
    if( class_exists( 'WC_Payment_Gateway' ) ) {
        require_once PLUGIN_PATH . '/src/class-wc-paypipes-gateway.php';
        require_once PLUGIN_PATH . '/src/locale.php';
    }
}

function register_paypipes( $methods ) {
    $methods[] = 'WC_Paypipes_Gateway';
    return $methods;
}

